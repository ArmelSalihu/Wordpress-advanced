<?php
/** Footer template. */
?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <a class="site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>">Movie<span>Hub</span></a>
                <p class="footer-text"><?php echo esc_html( get_theme_mod( 'moviehub_footer_text', 'Your home for discovering movies.' ) ); ?></p>
            </div>
            <div>
                <h2 class="footer-title"><?php esc_html_e( 'Explore', 'moviehub' ); ?></h2>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'items_wrap'     => '<ul class="footer-links">%3$s</ul>',
                ) );
                ?>
            </div>
            <div>
                <h2 class="footer-title"><?php esc_html_e( 'MovieHub', 'moviehub' ); ?></h2>
                <p class="footer-text"><?php esc_html_e( 'Discover new releases, fan favorites, and movies worth adding to your watchlist.', 'moviehub' ); ?></p>
            </div>
        </div>
        <div class="footer-bottom">
            <span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> MovieHub.</span>
            <span><?php esc_html_e( 'Built as a custom WordPress theme.', 'moviehub' ); ?></span>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
