<?php
if ( post_password_required() ) { return; }
?>
<section class="section" id="comments" style="padding-bottom:0;">
    <div class="content-card">
        <?php if ( have_comments() ) : ?>
            <h2 class="movie-title"><?php comments_number( __( 'Comments', 'moviehub' ), __( '1 Comment', 'moviehub' ), __( '% Comments', 'moviehub' ) ); ?></h2>
            <ol><?php wp_list_comments( array( 'style' => 'ol' ) ); ?></ol>
        <?php endif; ?>
        <?php comment_form(); ?>
    </div>
</section>
