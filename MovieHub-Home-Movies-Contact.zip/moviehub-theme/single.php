<?php
get_header();
while ( have_posts() ) : the_post();
?>
<section class="archive-hero"><div class="container"><div class="section-kicker"><?php esc_html_e( 'Blog', 'moviehub' ); ?></div><h1 class="section-title"><?php the_title(); ?></h1></div></section>
<section class="section"><div class="container archive-layout"><main class="content-card entry-content"><?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'large' ); endif; ?><p class="footer-text"><?php echo esc_html( get_the_date() ); ?></p><?php the_content(); ?></main><?php get_sidebar(); ?></div></section>
<?php
endwhile;
get_footer();
