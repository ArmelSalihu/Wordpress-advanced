<?php
get_header();
?>
<section class="archive-hero">
    <div class="container">
        <div class="section-kicker"><?php esc_html_e( 'MovieHub', 'moviehub' ); ?></div>
        <h1 class="section-title"><?php bloginfo( 'name' ); ?></h1>
    </div>
</section>
<section class="section">
    <div class="container archive-layout">
        <main>
            <?php if ( have_posts() ) : ?>
                <div class="movie-grid">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <article class="movie-card">
                            <?php if ( has_post_thumbnail() ) : ?><a class="movie-thumb" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?></a><?php endif; ?>
                            <div class="movie-body"><h2 class="movie-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p class="movie-excerpt"><?php echo esc_html( moviehub_trim_excerpt( get_the_excerpt(), 18 ) ); ?></p></div>
                        </article>
                    <?php endwhile; ?>
                </div>
                <?php get_template_part( 'template-parts/pagination' ); ?>
            <?php else : ?>
                <div class="content-card"><p><?php esc_html_e( 'Nothing found.', 'moviehub' ); ?></p></div>
            <?php endif; ?>
        </main>
        <?php get_sidebar(); ?>
    </div>
</section>
<?php get_footer(); ?>
