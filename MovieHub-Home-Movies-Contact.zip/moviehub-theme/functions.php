<?php
/**
 * MovieHub Advanced theme functions.
 */

define( 'MOVIEHUB_VERSION', '1.1.0' );

function moviehub_setup() {
    load_theme_textdomain( 'moviehub', get_template_directory() . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'moviehub' ),
        'footer'  => __( 'Footer Menu', 'moviehub' ),
    ) );
}
add_action( 'after_setup_theme', 'moviehub_setup' );


/**
 * Clean fallback menu used until a Primary Menu is assigned in Appearance > Menus.
 */
function moviehub_primary_fallback_menu() {
    $items = array(
        array(
            'url'     => home_url( '/' ),
            'label'   => __( 'Home', 'moviehub' ),
            'current' => is_front_page(),
        ),
        array(
            'url'     => get_post_type_archive_link( 'movie' ),
            'label'   => __( 'Movies', 'moviehub' ),
            'current' => is_post_type_archive( 'movie' ) || is_singular( 'movie' ),
        ),
    );

    $optional_pages = array(
        array( 'path' => 'about',   'label' => __( 'About', 'moviehub' ) ),
        array( 'path' => 'blog',    'label' => __( 'Blog', 'moviehub' ) ),
        array( 'path' => 'contact-us', 'label' => __( 'Contact Us', 'moviehub' ) ),
    );

    foreach ( $optional_pages as $page ) {
        $page_post = get_page_by_path( $page['path'] );
        if ( $page_post ) {
            $items[] = array(
                'url'     => get_permalink( $page_post ),
                'label'   => $page['label'],
                'current' => is_page( $page_post->ID ),
            );
        }
    }

    echo '<ul class="menu">';
    foreach ( $items as $item ) {
        if ( empty( $item['url'] ) ) {
            continue;
        }
        $current_class = $item['current'] ? ' current-menu-item' : '';
        $aria_current  = $item['current'] ? ' aria-current="page"' : '';
        echo '<li class="menu-item' . esc_attr( $current_class ) . '">';
        echo '<a href="' . esc_url( $item['url'] ) . '"' . $aria_current . '>' . esc_html( $item['label'] ) . '</a>';
        echo '</li>';
    }
    echo '</ul>';
}

function moviehub_assets() {
    wp_enqueue_style( 'moviehub-style', get_stylesheet_uri(), array(), MOVIEHUB_VERSION );
    wp_enqueue_script( 'moviehub-main', get_template_directory_uri() . '/assets/js/main.js', array(), MOVIEHUB_VERSION, true );

    $interval = absint( get_theme_mod( 'moviehub_slider_interval', 6000 ) );
    if ( $interval < 2500 ) {
        $interval = 2500;
    }
    wp_localize_script( 'moviehub-main', 'movieHubSettings', array(
        'sliderInterval' => $interval,
    ) );
}
add_action( 'wp_enqueue_scripts', 'moviehub_assets' );

function moviehub_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'moviehub' ),
        'id'            => 'main-sidebar',
        'description'   => __( 'Sidebar shown on archive and standard content pages.', 'moviehub' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'moviehub_widgets_init' );

function moviehub_register_content() {
    register_post_type( 'movie', array(
        'labels' => array(
            'name'               => __( 'Movies', 'moviehub' ),
            'singular_name'      => __( 'Movie', 'moviehub' ),
            'menu_name'          => __( 'Movies', 'moviehub' ),
            'add_new'            => __( 'Add Movie', 'moviehub' ),
            'add_new_item'       => __( 'Add New Movie', 'moviehub' ),
            'edit_item'          => __( 'Edit Movie', 'moviehub' ),
            'new_item'           => __( 'New Movie', 'moviehub' ),
            'view_item'          => __( 'View Movie', 'moviehub' ),
            'search_items'       => __( 'Search Movies', 'moviehub' ),
            'not_found'          => __( 'No movies found', 'moviehub' ),
            'not_found_in_trash' => __( 'No movies found in Trash', 'moviehub' ),
        ),
        'public'             => true,
        'has_archive'        => true,
        'rewrite'            => array( 'slug' => 'movies' ),
        'menu_icon'          => 'dashicons-format-video',
        'show_in_rest'       => true,
        'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail', 'author', 'comments', 'revisions' ),
    ) );

    register_taxonomy( 'genre', array( 'movie' ), array(
        'labels' => array(
            'name'          => __( 'Genres', 'moviehub' ),
            'singular_name' => __( 'Genre', 'moviehub' ),
        ),
        'public'            => true,
        'hierarchical'      => true,
        'show_in_rest'      => true,
        'rewrite'           => array( 'slug' => 'genre' ),
    ) );
}
add_action( 'init', 'moviehub_register_content' );

function moviehub_flush_rewrites() {
    moviehub_register_content();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'moviehub_flush_rewrites' );

function moviehub_add_meta_boxes() {
    // Keep the slider toggle in the WordPress editor sidebar, like the screenshot.
    add_meta_box(
        'moviehub_homepage_slider',
        __( 'Homepage Slider', 'moviehub' ),
        'moviehub_homepage_slider_meta_box',
        'movie',
        'side',
        'high'
    );

    add_meta_box(
        'moviehub_movie_details',
        __( 'Movie Details', 'moviehub' ),
        'moviehub_movie_details_meta_box',
        'movie',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes_movie', 'moviehub_add_meta_boxes' );

function moviehub_homepage_slider_meta_box( $post ) {
    wp_nonce_field( 'moviehub_save_homepage_slider', 'moviehub_slider_nonce' );
    $featured = get_post_meta( $post->ID, '_moviehub_featured', true );
    ?>
    <p>
        <label>
            <input type="checkbox" name="moviehub_featured" value="1" <?php checked( $featured, '1' ); ?>>
            <?php esc_html_e( 'Add this movie to the homepage slider', 'moviehub' ); ?>
        </label>
    </p>
    <p class="description">
        <?php esc_html_e( 'Use the Featured Image for the slider background. The movie title and description are used as the slider text.', 'moviehub' ); ?>
    </p>
    <?php
}

function moviehub_movie_details_meta_box( $post ) {
    wp_nonce_field( 'moviehub_save_movie_details', 'moviehub_movie_nonce' );

    $fields = array(
        'rating'        => get_post_meta( $post->ID, '_moviehub_rating', true ),
        'release_year'  => get_post_meta( $post->ID, '_moviehub_release_year', true ),
        'director'      => get_post_meta( $post->ID, '_moviehub_director', true ),
        'cast'          => get_post_meta( $post->ID, '_moviehub_cast', true ),
        'trailer_url'   => get_post_meta( $post->ID, '_moviehub_trailer_url', true ),
        'hero_subtitle' => get_post_meta( $post->ID, '_moviehub_hero_subtitle', true ),
        'button_text'   => get_post_meta( $post->ID, '_moviehub_button_text', true ),
    );
    ?>
    <p><?php esc_html_e( 'Set the movie information shown on the MovieHub cards and single movie page.', 'moviehub' ); ?></p>
    <table class="form-table" role="presentation">
        <tr><th><label for="moviehub_rating"><?php esc_html_e( 'Rating', 'moviehub' ); ?></label></th><td><input type="number" min="0" max="10" step="0.1" id="moviehub_rating" name="moviehub_rating" value="<?php echo esc_attr( $fields['rating'] ); ?>" class="regular-text"></td></tr>
        <tr><th><label for="moviehub_release_year"><?php esc_html_e( 'Release Year', 'moviehub' ); ?></label></th><td><input type="number" min="1888" max="2100" id="moviehub_release_year" name="moviehub_release_year" value="<?php echo esc_attr( $fields['release_year'] ); ?>" class="regular-text"></td></tr>
        <tr><th><label for="moviehub_director"><?php esc_html_e( 'Director', 'moviehub' ); ?></label></th><td><input type="text" id="moviehub_director" name="moviehub_director" value="<?php echo esc_attr( $fields['director'] ); ?>" class="regular-text"></td></tr>
        <tr><th><label for="moviehub_cast"><?php esc_html_e( 'Cast', 'moviehub' ); ?></label></th><td><input type="text" id="moviehub_cast" name="moviehub_cast" value="<?php echo esc_attr( $fields['cast'] ); ?>" class="large-text"></td></tr>
        <tr><th><label for="moviehub_trailer_url"><?php esc_html_e( 'Trailer URL', 'moviehub' ); ?></label></th><td><input type="url" id="moviehub_trailer_url" name="moviehub_trailer_url" value="<?php echo esc_attr( $fields['trailer_url'] ); ?>" class="large-text"></td></tr>
        <tr><th><label for="moviehub_hero_subtitle"><?php esc_html_e( 'Hero Subtitle', 'moviehub' ); ?></label></th><td><textarea id="moviehub_hero_subtitle" name="moviehub_hero_subtitle" rows="3" class="large-text"><?php echo esc_textarea( $fields['hero_subtitle'] ); ?></textarea></td></tr>
        <tr><th><label for="moviehub_button_text"><?php esc_html_e( 'Hero Button Text', 'moviehub' ); ?></label></th><td><input type="text" id="moviehub_button_text" name="moviehub_button_text" value="<?php echo esc_attr( $fields['button_text'] ); ?>" class="regular-text"></td></tr>
    </table>
    <?php
}

function moviehub_save_movie_details( $post_id ) {
    $details_nonce_valid = isset( $_POST['moviehub_movie_nonce'] )
        && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['moviehub_movie_nonce'] ) ), 'moviehub_save_movie_details' );
    $slider_nonce_valid = isset( $_POST['moviehub_slider_nonce'] )
        && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['moviehub_slider_nonce'] ) ), 'moviehub_save_homepage_slider' );

    if ( ! $details_nonce_valid && ! $slider_nonce_valid ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( $slider_nonce_valid ) {
        update_post_meta( $post_id, '_moviehub_featured', isset( $_POST['moviehub_featured'] ) ? '1' : '0' );
    }

    if ( ! $details_nonce_valid ) {
        return;
    }
    $map = array(
        'moviehub_rating'        => '_moviehub_rating',
        'moviehub_release_year'  => '_moviehub_release_year',
        'moviehub_director'      => '_moviehub_director',
        'moviehub_cast'          => '_moviehub_cast',
        'moviehub_trailer_url'   => '_moviehub_trailer_url',
        'moviehub_hero_subtitle' => '_moviehub_hero_subtitle',
        'moviehub_button_text'   => '_moviehub_button_text',
    );
    foreach ( $map as $input => $meta_key ) {
        if ( isset( $_POST[ $input ] ) ) {
            $value = wp_unslash( $_POST[ $input ] );
            if ( 'moviehub_trailer_url' === $input ) {
                $value = esc_url_raw( $value );
            } elseif ( 'moviehub_rating' === $input ) {
                $value = max( 0, min( 10, (float) $value ) );
            } elseif ( 'moviehub_release_year' === $input ) {
                $value = absint( $value );
            } else {
                $value = sanitize_textarea_field( $value );
            }
            update_post_meta( $post_id, $meta_key, $value );
        } else {
            delete_post_meta( $post_id, $meta_key );
        }
    }
}
add_action( 'save_post_movie', 'moviehub_save_movie_details' );

function moviehub_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'moviehub_settings', array(
        'title'       => __( 'MovieHub Settings', 'moviehub' ),
        'priority'    => 35,
        'description' => __( 'Control the homepage slider timing and footer text.', 'moviehub' ),
    ) );

    $wp_customize->add_setting( 'moviehub_slider_interval', array(
        'default'           => 6000,
        'sanitize_callback' => function( $value ) { return absint( $value ); },
    ) );
    $wp_customize->add_control( 'moviehub_slider_interval', array(
        'label'       => __( 'Slider Autoplay (milliseconds)', 'moviehub' ),
        'section'     => 'moviehub_settings',
        'type'        => 'number',
        'input_attrs' => array( 'min' => 2500, 'step' => 500 ),
    ) );

    $wp_customize->add_setting( 'moviehub_footer_text', array(
        'default'           => 'Your home for discovering movies.',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'moviehub_footer_text', array(
        'label'   => __( 'Footer Description', 'moviehub' ),
        'section' => 'moviehub_settings',
        'type'    => 'text',
    ) );
}
add_action( 'customize_register', 'moviehub_customize_register' );

function moviehub_movie_search_query( $query ) {
    if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
        return;
    }

    $query->set( 'post_type', 'movie' );
    $query->set( 'posts_per_page', 12 );
}
add_action( 'pre_get_posts', 'moviehub_movie_search_query' );

function moviehub_trim_excerpt( $text, $length = 24 ) {
    return wp_trim_words( wp_strip_all_tags( $text ), $length, '…' );
}

function moviehub_get_slider_movies() {
    $featured = new WP_Query( array(
        'post_type'      => 'movie',
        'posts_per_page' => 5,
        'post_status'    => 'publish',
        'meta_key'       => '_moviehub_featured',
        'meta_value'     => '1',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ) );

    if ( $featured->have_posts() ) {
        return $featured;
    }

    wp_reset_postdata();
    return new WP_Query( array(
        'post_type'      => 'movie',
        'posts_per_page' => 5,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ) );
}

function moviehub_admin_columns( $columns ) {
    $columns['movie_rating'] = __( 'Rating', 'moviehub' );
    $columns['movie_featured'] = __( 'Hero Slider', 'moviehub' );
    return $columns;
}
add_filter( 'manage_movie_posts_columns', 'moviehub_admin_columns' );

function moviehub_admin_column_content( $column, $post_id ) {
    if ( 'movie_rating' === $column ) {
        $rating = get_post_meta( $post_id, '_moviehub_rating', true );
        echo $rating ? esc_html( $rating . '/10' ) : '—';
    }
    if ( 'movie_featured' === $column ) {
        echo '1' === get_post_meta( $post_id, '_moviehub_featured', true ) ? '✓' : '—';
    }
}
add_action( 'manage_movie_posts_custom_column', 'moviehub_admin_column_content', 10, 2 );

/**
 * Create/repair the Contact Us page and keep the primary menu ordered as:
 * Home → Movies → Contact Us.
 */
function moviehub_create_contact_page_and_menu() {
    $contact_page = get_page_by_path( 'contact-us', OBJECT, 'page' );

    if ( ! $contact_page ) {
        $page_id = wp_insert_post( array(
            'post_title'   => 'Contact Us',
            'post_name'    => 'contact-us',
            'post_content' => '',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ) );

        if ( ! is_wp_error( $page_id ) ) {
            update_post_meta( $page_id, '_wp_page_template', 'page-contact.php' );
            $contact_page = get_post( $page_id );
        }
    } elseif ( 'page-contact.php' !== get_post_meta( $contact_page->ID, '_wp_page_template', true ) ) {
        update_post_meta( $contact_page->ID, '_wp_page_template', 'page-contact.php' );
    }

    if ( ! $contact_page ) {
        return;
    }

    $locations = get_theme_mod( 'nav_menu_locations' );
    $menu_id   = ! empty( $locations['primary'] ) ? (int) $locations['primary'] : 0;

    // Create a dedicated primary menu when none is assigned yet.
    if ( ! $menu_id ) {
        $menu_id = wp_create_nav_menu( 'MovieHub Main Menu' );

        if ( is_wp_error( $menu_id ) ) {
            return;
        }

        wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'     => 'Home',
            'menu-item-url'       => home_url( '/' ),
            'menu-item-position'  => 1,
            'menu-item-status'    => 'publish',
        ) );

        $movies_url = get_post_type_archive_link( 'movie' );
        if ( $movies_url ) {
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'     => 'Movies',
                'menu-item-url'       => $movies_url,
                'menu-item-position'  => 2,
                'menu-item-status'    => 'publish',
            ) );
        }

        wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'     => 'Contact Us',
            'menu-item-object'    => 'page',
            'menu-item-object-id' => $contact_page->ID,
            'menu-item-type'      => 'post_type',
            'menu-item-position'  => 3,
            'menu-item-status'    => 'publish',
        ) );

        $locations['primary'] = $menu_id;
        set_theme_mod( 'nav_menu_locations', $locations );
        return;
    }

    $menu_items       = wp_get_nav_menu_items( $menu_id, array( 'orderby' => 'menu_order', 'order' => 'ASC' ) );
    $home_item        = null;
    $movies_item      = null;
    $contact_item     = null;
    $movies_url       = get_post_type_archive_link( 'movie' );
    $home_url         = home_url( '/' );

    if ( $menu_items ) {
        foreach ( $menu_items as $menu_item ) {
            $item_url = untrailingslashit( $menu_item->url );

            if ( ! $home_item && ( 'Home' === trim( $menu_item->title ) || untrailingslashit( $home_url ) === $item_url ) ) {
                $home_item = $menu_item;
            }

            if ( ! $movies_item && (
                ( 'post_type_archive' === $menu_item->type && 'movie' === $menu_item->object ) ||
                'Movies' === trim( $menu_item->title ) ||
                ( $movies_url && untrailingslashit( $movies_url ) === $item_url )
            ) ) {
                $movies_item = $menu_item;
            }

            if ( ! $contact_item && 'post_type' === $menu_item->type && 'page' === $menu_item->object && (int) $menu_item->object_id === (int) $contact_page->ID ) {
                $contact_item = $menu_item;
            }
        }
    }

    // Add missing Home and Movies items so the requested order always exists.
    if ( ! $home_item ) {
        $home_id = wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'    => 'Home',
            'menu-item-url'      => $home_url,
            'menu-item-position' => 1,
            'menu-item-status'   => 'publish',
        ) );
        if ( ! is_wp_error( $home_id ) ) {
            $home_item = get_post( $home_id );
        }
    }

    if ( ! $movies_item && $movies_url ) {
        $movies_id = wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'    => 'Movies',
            'menu-item-url'      => $movies_url,
            'menu-item-position' => 2,
            'menu-item-status'   => 'publish',
        ) );
        if ( ! is_wp_error( $movies_id ) ) {
            $movies_item = get_post( $movies_id );
        }
    }

    if ( ! $contact_item ) {
        $contact_id = wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'     => 'Contact Us',
            'menu-item-object'    => 'page',
            'menu-item-object-id' => $contact_page->ID,
            'menu-item-type'      => 'post_type',
            'menu-item-status'    => 'publish',
        ) );
        if ( ! is_wp_error( $contact_id ) ) {
            $contact_item = get_post( $contact_id );
        }
    }

    // Put the three main links at the start in the exact order requested.
    if ( $home_item ) {
        wp_update_nav_menu_item( $menu_id, $home_item->db_id, array(
            'menu-item-position' => 1,
            'menu-item-status'   => 'publish',
        ) );
    }
    if ( $movies_item ) {
        wp_update_nav_menu_item( $menu_id, $movies_item->db_id, array(
            'menu-item-position' => 2,
            'menu-item-status'   => 'publish',
        ) );
    }
    if ( $contact_item ) {
        wp_update_nav_menu_item( $menu_id, $contact_item->db_id, array(
            'menu-item-position' => 3,
            'menu-item-title'    => 'Contact Us',
            'menu-item-status'   => 'publish',
        ) );
    }
}
add_action( 'after_switch_theme', 'moviehub_create_contact_page_and_menu', 20 );

/**
 * Repair/create the Contact Us page and menu item after theme updates too.
 * This is needed because after_switch_theme only runs when the theme is activated,
 * not when a ZIP is uploaded over an already-active theme.
 */
function moviehub_ensure_contact_page_and_menu() {
    if ( get_option( 'moviehub_contact_setup_v3' ) ) {
        return;
    }

    moviehub_create_contact_page_and_menu();
    update_option( 'moviehub_contact_setup_v3', 1 );
}
add_action( 'admin_init', 'moviehub_ensure_contact_page_and_menu', 20 );

/**
 * Handle the Contact Us form.
 */
function moviehub_handle_contact_form() {
    if ( ! isset( $_POST['moviehub_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['moviehub_contact_nonce'] ) ), 'moviehub_contact_form_action' ) ) {
        wp_safe_redirect( home_url( '/contact-us/?contact_status=error' ) );
        exit;
    }

    $name    = isset( $_POST['moviehub_name'] ) ? sanitize_text_field( wp_unslash( $_POST['moviehub_name'] ) ) : '';
    $email   = isset( $_POST['moviehub_email'] ) ? sanitize_email( wp_unslash( $_POST['moviehub_email'] ) ) : '';
    $subject = isset( $_POST['moviehub_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['moviehub_subject'] ) ) : '';
    $message = isset( $_POST['moviehub_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['moviehub_message'] ) ) : '';

    if ( ! $name || ! is_email( $email ) || ! $subject || ! $message ) {
        wp_safe_redirect( home_url( '/contact-us/?contact_status=error' ) );
        exit;
    }

    $to      = get_option( 'admin_email' );
    $mail_subject = sprintf( 'MovieHub Contact: %s', $subject );
    $mail_body = "Name: {$name}\nEmail: {$email}\n\nMessage:\n{$message}";
    $headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

    $sent = wp_mail( $to, $mail_subject, $mail_body, $headers );

    wp_safe_redirect( home_url( '/contact-us/?contact_status=' . ( $sent ? 'success' : 'error' ) ) );
    exit;
}
add_action( 'admin_post_moviehub_contact_form', 'moviehub_handle_contact_form' );
add_action( 'admin_post_nopriv_moviehub_contact_form', 'moviehub_handle_contact_form' );
