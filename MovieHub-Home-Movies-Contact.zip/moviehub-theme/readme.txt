MOVIEHUB ADVANCED WORDPRESS THEME

1. Install
- Zip the moviehub-theme folder.
- In WordPress go to Appearance -> Themes -> Add New -> Upload Theme.
- Upload moviehub-theme.zip and activate it.

2. Set up the homepage
- Create a page called Home.
- Go to Settings -> Reading -> Your homepage displays -> A static page.
- Select Home as the homepage.
- The theme's front-page.php will display the MovieHub homepage.

3. Create movies
- In the WordPress dashboard open Movies -> Add Movie.
- Add a title.
- Add the movie description/content.
- Add an Excerpt for the short description.
- Set a Featured Image. This becomes the movie poster and also the slider background.
- Choose a Genre.
- Fill in Movie Details.
- Tick “Show this movie in the homepage Hero Slider” to include it in the slider.

4. Changing slider text and image
- Change the Movie title to change the main slider title.
- Change the Featured Image to change the slider image.
- Change the Excerpt or Hero Subtitle to change the slider description.
- Change Hero Button Text to change the main button label.
- You can select up to 5 featured movies for the hero slider.

5. Menus
- Go to Appearance -> Menus (or Appearance -> Editor depending on WordPress version).
- Assign a menu to Primary Menu.
- Optionally assign another menu to Footer Menu.

6. Customization
- Appearance -> Customize -> MovieHub Settings lets you change slider autoplay timing and footer description on classic-theme setups that expose the Customizer.
- Add a Custom Logo through WordPress Site Identity.

7. Movies archive page
- The Movies post type has its own archive at /movies/.
- The archive shows all published movies with pagination.
- Visitors can filter the movie archive by Genre.
- The page includes the MovieHub sidebar and search.

8. Recommended pages
Home, Movies (archive comes from the Movies post type), About, Contact, and Blog.

This theme uses WordPress core APIs for theme support, menus, featured images, custom post types, taxonomies, widgets, and the editor.

CONTACT US
- The theme automatically creates a "Contact Us" page when activated.
- It uses page-contact.php and is added to the Primary Menu automatically.
- The contact form sends messages to the WordPress admin email via wp_mail().
