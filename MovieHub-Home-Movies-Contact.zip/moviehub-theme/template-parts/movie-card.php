<?php
/** Movie card partial. */
$rating = get_post_meta( get_the_ID(), '_moviehub_rating', true );
$year   = get_post_meta( get_the_ID(), '_moviehub_release_year', true );
?>
<article class="movie-card">
    <a class="movie-thumb" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'View %s', 'moviehub' ), get_the_title() ) ); ?>">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
        <?php else : ?>
            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/movie-placeholder.svg' ); ?>" alt="">
        <?php endif; ?>
    </a>
    <div class="movie-body">
        <h3 class="movie-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p class="movie-excerpt"><?php echo esc_html( moviehub_trim_excerpt( get_the_excerpt(), 16 ) ); ?></p>
        <div class="movie-meta-row">
            <span><?php echo $year ? esc_html( $year ) : esc_html( get_the_date( 'Y' ) ); ?></span>
            <span class="movie-rating"><?php echo $rating ? esc_html( '★ ' . $rating ) : esc_html__( 'Movie', 'moviehub' ); ?></span>
        </div>
    </div>
</article>
