<?php
/**
 * Reusable pagination.
 * Accepts an optional WP_Query in $args['query']; otherwise uses the main query.
 */
$query = isset( $args['query'] ) && $args['query'] instanceof WP_Query ? $args['query'] : $GLOBALS['wp_query'];
$current = max( 1, (int) get_query_var( 'paged' ) );
$total   = (int) $query->max_num_pages;

if ( $total < 2 ) {
    return;
}

$base_url = get_pagenum_link( 1 );

if ( isset( $_GET['genre'] ) && '' !== $_GET['genre'] ) {
    $base_url = add_query_arg( 'genre', sanitize_title( wp_unslash( $_GET['genre'] ) ), $base_url );
}

$links = paginate_links(
    array(
        'base'      => trailingslashit( $base_url ) . '%_%',
        'format'    => 'page/%#%/',
        'current'   => $current,
        'total'     => $total,
        'mid_size'  => 2,
        'end_size'  => 1,
        'prev_text' => esc_html__( '« Prev', 'moviehub' ),
        'next_text' => esc_html__( 'Next »', 'moviehub' ),
        'type'      => 'list',
    )
);

if ( $links ) : ?>
    <nav class="pagination" aria-label="<?php esc_attr_e( 'Pagination', 'moviehub' ); ?>">
        <?php echo wp_kses_post( $links ); ?>
    </nav>
<?php endif; ?>
