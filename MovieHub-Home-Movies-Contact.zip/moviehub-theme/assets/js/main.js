(function () {
  'use strict';

  const root = document.querySelector('[data-slider]');
  if (root) {
    const slides = Array.from(root.querySelectorAll('.hero-slide'));
    const dots = Array.from(root.querySelectorAll('[data-slider-dot]'));
    const previous = root.querySelector('[data-slider-prev]');
    const next = root.querySelector('[data-slider-next]');
    let current = 0;
    let timer = null;

    const showSlide = (index) => {
      if (!slides.length) return;
      current = (index + slides.length) % slides.length;
      slides.forEach((slide, i) => slide.classList.toggle('is-active', i === current));
      dots.forEach((dot, i) => dot.classList.toggle('is-active', i === current));
    };

    const start = () => {
      stop();
      if (slides.length > 1 && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)) {
        const interval = Number(window.movieHubSettings && window.movieHubSettings.sliderInterval) || 6000;
        timer = window.setInterval(() => showSlide(current + 1), interval);
      }
    };
    const stop = () => { if (timer) { window.clearInterval(timer); timer = null; } };

    previous && previous.addEventListener('click', () => { showSlide(current - 1); start(); });
    next && next.addEventListener('click', () => { showSlide(current + 1); start(); });
    dots.forEach((dot) => dot.addEventListener('click', () => { showSlide(Number(dot.dataset.sliderDot)); start(); }));
    root.addEventListener('mouseenter', stop);
    root.addEventListener('mouseleave', start);
    root.addEventListener('focusin', stop);
    root.addEventListener('focusout', start);
    start();
  }

  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.primary-nav');
  if (menuToggle && nav) {
    const closeMenu = () => {
      menuToggle.setAttribute('aria-expanded', 'false');
      nav.classList.remove('is-open');
    };

    menuToggle.addEventListener('click', () => {
      const open = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!open));
      nav.classList.toggle('is-open', !open);
    });

    document.addEventListener('click', (event) => {
      if (!nav.contains(event.target) && !menuToggle.contains(event.target)) closeMenu();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeMenu();
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => closeMenu());
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 820) closeMenu();
    });
  }

  const searchToggle = document.querySelector('.search-toggle');
  const search = document.querySelector('.header-search');
  if (searchToggle && search) {
    searchToggle.addEventListener('click', () => {
      const open = searchToggle.getAttribute('aria-expanded') === 'true';
      searchToggle.setAttribute('aria-expanded', String(!open));
      search.classList.toggle('is-open', !open);
      if (!open) {
        const input = search.querySelector('input[type="search"]');
        if (input) input.focus();
      }
    });
  }
})();
