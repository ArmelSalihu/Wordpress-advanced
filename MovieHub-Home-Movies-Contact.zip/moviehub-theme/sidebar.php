<aside class="sidebar" aria-label="<?php esc_attr_e( 'MovieHub Sidebar', 'moviehub' ); ?>">
    <section class="widget widget-search">
        <h2 class="widget-title"><?php esc_html_e( 'Search Movies', 'moviehub' ); ?></h2>
        <?php get_search_form(); ?>
    </section>

    <section class="widget">
        <h2 class="widget-title"><?php esc_html_e( 'Browse Genres', 'moviehub' ); ?></h2>
        <?php $genres = get_terms( array( 'taxonomy' => 'genre', 'hide_empty' => true, 'number' => 10 ) ); ?>
        <?php if ( ! empty( $genres ) && ! is_wp_error( $genres ) ) : ?>
            <ul class="sidebar-list">
                <?php foreach ( $genres as $genre ) : ?>
                    <li>
                        <a href="<?php echo esc_url( get_term_link( $genre ) ); ?>">
                            <span><?php echo esc_html( $genre->name ); ?></span>
                            <span class="sidebar-count"><?php echo esc_html( $genre->count ); ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p class="footer-text"><?php esc_html_e( 'Add genres to your movies to see them here.', 'moviehub' ); ?></p>
        <?php endif; ?>
    </section>

    <section class="widget">
        <h2 class="widget-title"><?php esc_html_e( 'Latest Movies', 'moviehub' ); ?></h2>
        <?php
        $sidebar_movies = new WP_Query( array(
            'post_type'      => 'movie',
            'posts_per_page' => 4,
            'post_status'    => 'publish',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );
        ?>
        <?php if ( $sidebar_movies->have_posts() ) : ?>
            <div class="sidebar-movie-list">
                <?php while ( $sidebar_movies->have_posts() ) : $sidebar_movies->the_post(); ?>
                    <a class="sidebar-movie" href="<?php the_permalink(); ?>">
                        <span class="sidebar-movie-thumb">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <?php the_post_thumbnail( 'thumbnail', array( 'loading' => 'lazy' ) ); ?>
                            <?php else : ?>
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/movie-placeholder.svg' ); ?>" alt="" loading="lazy">
                            <?php endif; ?>
                        </span>
                        <span class="sidebar-movie-info">
                            <strong><?php the_title(); ?></strong>
                            <small><?php echo esc_html( get_the_date() ); ?></small>
                        </span>
                    </a>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <p class="footer-text"><?php esc_html_e( 'No movies have been published yet.', 'moviehub' ); ?></p>
        <?php endif; ?>
    </section>

    <?php if ( is_active_sidebar( 'main-sidebar' ) ) : ?>
        <?php dynamic_sidebar( 'main-sidebar' ); ?>
    <?php endif; ?>
</aside>
