<?php
get_header();
?>

<main id="primary" class="site-main error-page">
    <section class="not-found">
        <div class="container not-found-inner">
            <div class="not-found-art" aria-hidden="true">
                <span>404</span>
                <div class="film-strip film-strip-one"></div>
                <div class="film-strip film-strip-two"></div>
            </div>

            <div class="section-kicker"><?php esc_html_e( 'Scene not found', 'moviehub' ); ?></div>
            <h1 class="section-title"><?php esc_html_e( 'This page missed the premiere.', 'moviehub' ); ?></h1>
            <p class="section-description not-found-description">
                <?php esc_html_e( 'The page you are looking for does not exist, has moved, or is no longer available.', 'moviehub' ); ?>
            </p>

            <div class="not-found-actions">
                <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <?php esc_html_e( 'Back to Home', 'moviehub' ); ?>
                </a>
                <a class="btn btn-secondary" href="<?php echo esc_url( get_post_type_archive_link( 'movie' ) ); ?>">
                    <?php esc_html_e( 'Browse Movies', 'moviehub' ); ?>
                </a>
            </div>

            <div class="not-found-search">
                <p><?php esc_html_e( 'Search MovieHub:', 'moviehub' ); ?></p>
                <?php get_search_form(); ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
