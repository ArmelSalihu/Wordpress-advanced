<?php
/**
 * Template Name: Contact Us
 * Template Post Type: page
 *
 * Custom MovieHub contact page.
 */
get_header();

$status = isset( $_GET['contact_status'] ) ? sanitize_key( wp_unslash( $_GET['contact_status'] ) ) : '';
?>

<main id="primary" class="site-main contact-page">
    <section class="contact-hero">
        <div class="container contact-hero-inner">
            <div>
                <div class="section-kicker">MovieHub</div>
                <h1>Contact Us</h1>
                <p>Have a question, movie suggestion, or something you want us to know? Send us a message and the MovieHub team will get back to you.</p>
            </div>
        </div>
    </section>

    <section class="section contact-section">
        <div class="container contact-layout">
            <div class="contact-info">
                <div class="section-kicker">Get in touch</div>
                <h2>Let's talk movies.</h2>
                <p class="contact-intro">Use the form to contact MovieHub. You can also use the details below for general questions and suggestions.</p>

                <div class="contact-info-list">
                    <a class="contact-info-card" href="mailto:hello@moviehub.local">
                        <span class="contact-icon" aria-hidden="true">✉</span>
                        <span><strong>Email</strong><small>hello@moviehub.local</small></span>
                    </a>
                    <div class="contact-info-card">
                        <span class="contact-icon" aria-hidden="true">⌖</span>
                        <span><strong>Location</strong><small>MovieHub Studio, Cinema District</small></span>
                    </div>
                    <div class="contact-info-card">
                        <span class="contact-icon" aria-hidden="true">◷</span>
                        <span><strong>Response Time</strong><small>Usually within 1–2 business days</small></span>
                    </div>
                </div>

                <div class="contact-social-note">
                    <span class="contact-social-dot"></span>
                    <span>Follow MovieHub for new movie updates and announcements.</span>
                </div>
            </div>

            <div class="contact-form-card">
                <div class="form-heading">
                    <div class="section-kicker">Send a message</div>
                    <h2>Tell us what you need.</h2>
                </div>

                <?php if ( 'success' === $status ) : ?>
                    <div class="contact-notice success" role="status">Thanks! Your message was sent successfully.</div>
                <?php elseif ( 'error' === $status ) : ?>
                    <div class="contact-notice error" role="alert">Sorry, something went wrong. Please check your details and try again.</div>
                <?php endif; ?>

                <form class="moviehub-contact-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
                    <input type="hidden" name="action" value="moviehub_contact_form">
                    <?php wp_nonce_field( 'moviehub_contact_form_action', 'moviehub_contact_nonce' ); ?>

                    <div class="form-grid">
                        <p>
                            <label for="moviehub_name">Name</label>
                            <input id="moviehub_name" type="text" name="moviehub_name" required autocomplete="name">
                        </p>
                        <p>
                            <label for="moviehub_email">Email</label>
                            <input id="moviehub_email" type="email" name="moviehub_email" required autocomplete="email">
                        </p>
                    </div>

                    <p>
                        <label for="moviehub_subject">Subject</label>
                        <input id="moviehub_subject" type="text" name="moviehub_subject" required>
                    </p>

                    <p>
                        <label for="moviehub_message">Message</label>
                        <textarea id="moviehub_message" name="moviehub_message" rows="7" required></textarea>
                    </p>

                    <button class="btn btn-primary contact-submit" type="submit">Send Message <span aria-hidden="true">→</span></button>
                </form>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
