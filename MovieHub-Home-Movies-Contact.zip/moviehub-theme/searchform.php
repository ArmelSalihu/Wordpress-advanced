<?php
/**
 * MovieHub search form.
 */
$search_id = wp_unique_id( 'moviehub-search-' );
?>
<form role="search" method="get" class="search-form moviehub-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <label class="search-label" for="<?php echo esc_attr( $search_id ); ?>">
        <span class="screen-reader-text"><?php esc_html_e( 'Search movies for:', 'moviehub' ); ?></span>
        <input
            id="<?php echo esc_attr( $search_id ); ?>"
            type="search"
            class="search-field"
            placeholder="<?php echo esc_attr_x( 'Search movies…', 'placeholder', 'moviehub' ); ?>"
            value="<?php echo esc_attr( get_search_query() ); ?>"
            name="s"
            autocomplete="off"
        />
    </label>
    <input type="hidden" name="post_type" value="movie" />
    <button class="search-submit button button-primary" type="submit">
        <?php esc_html_e( 'Search', 'moviehub' ); ?>
    </button>
</form>
