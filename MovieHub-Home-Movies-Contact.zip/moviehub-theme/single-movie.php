<?php
get_header();
while ( have_posts() ) : the_post();
    $rating       = get_post_meta( get_the_ID(), '_moviehub_rating', true );
    $year         = get_post_meta( get_the_ID(), '_moviehub_release_year', true );
    $director     = get_post_meta( get_the_ID(), '_moviehub_director', true );
    $cast         = get_post_meta( get_the_ID(), '_moviehub_cast', true );
    $trailer_url  = get_post_meta( get_the_ID(), '_moviehub_trailer_url', true );
    $genres       = get_the_terms( get_the_ID(), 'genre' );
?>
<section class="single-hero">
    <div class="container single-layout">
        <aside class="poster-card">
            <?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'large' ); else : ?><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/movie-placeholder.svg' ); ?>" alt=""><?php endif; ?>
        </aside>
        <main class="single-content">
            <div class="eyebrow"><span class="eyebrow-dot"></span><?php esc_html_e( 'Movie', 'moviehub' ); ?></div>
            <h1><?php the_title(); ?></h1>
            <?php if ( has_excerpt() ) : ?><p class="lead"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
            <div class="hero-meta">
                <?php if ( $year ) : ?><span class="meta-pill"><?php echo esc_html( $year ); ?></span><?php endif; ?>
                <?php if ( $rating ) : ?><span class="meta-pill rating">★ <?php echo esc_html( $rating ); ?>/10</span><?php endif; ?>
                <?php if ( $genres && ! is_wp_error( $genres ) ) : ?><span class="meta-pill"><?php echo esc_html( implode( ', ', wp_list_pluck( $genres, 'name' ) ) ); ?></span><?php endif; ?>
            </div>
            <div class="detail-grid">
                <?php if ( $director ) : ?><div class="detail"><span class="detail-label"><?php esc_html_e( 'Director', 'moviehub' ); ?></span><?php echo esc_html( $director ); ?></div><?php endif; ?>
                <?php if ( $cast ) : ?><div class="detail"><span class="detail-label"><?php esc_html_e( 'Cast', 'moviehub' ); ?></span><?php echo esc_html( $cast ); ?></div><?php endif; ?>
                <div class="detail"><span class="detail-label"><?php esc_html_e( 'Published', 'moviehub' ); ?></span><?php echo esc_html( get_the_date() ); ?></div>
                <div class="detail"><span class="detail-label"><?php esc_html_e( 'Comments', 'moviehub' ); ?></span><?php echo esc_html( get_comments_number() ); ?></div>
            </div>
            <div class="content-card entry-content"><?php the_content(); ?></div>
            <?php if ( $trailer_url ) : ?>
                <div class="trailer-wrap">
                    <div class="section-kicker"><?php esc_html_e( 'Trailer', 'moviehub' ); ?></div>
                    <iframe class="trailer" src="<?php echo esc_url( $trailer_url ); ?>" title="<?php echo esc_attr( get_the_title() . ' trailer' ); ?>" loading="lazy" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>
                </div>
            <?php endif; ?>
            <?php comments_template(); ?>
        </main>
    </div>
</section>
<?php
endwhile;
get_footer();
