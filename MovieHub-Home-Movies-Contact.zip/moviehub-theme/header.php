<?php
/** Header template. */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="container header-inner">
        <div class="branding">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a class="site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php bloginfo( 'name' ); ?>">
                    <span class="site-title-main">Movie</span><span class="site-title-accent">Hub</span>
                </a>
            <?php endif; ?>
        </div>

        <nav class="primary-nav" id="primary-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'moviehub' ); ?>">
            <div class="nav-panel">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => 'moviehub_primary_fallback_menu',
                    'depth'          => 2,
                    'menu_class'     => 'menu',
                ) );
                ?>
            </div>
        </nav>

        <div class="header-actions">
            <button class="search-toggle" type="button" aria-controls="header-search" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open search', 'moviehub' ); ?>">
                <span class="search-icon" aria-hidden="true"></span>
            </button>
            <a class="header-cta" href="<?php echo esc_url( get_post_type_archive_link( 'movie' ) ); ?>"><?php esc_html_e( 'Browse Movies', 'moviehub' ); ?></a>
            <button class="menu-toggle" type="button" aria-controls="primary-navigation" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open menu', 'moviehub' ); ?>">
                <span class="menu-icon" aria-hidden="true"><span></span><span></span><span></span></span>
            </button>
        </div>
    </div>

    <div class="header-search" id="header-search">
        <div class="container header-search-inner">
            <?php get_search_form(); ?>
        </div>
    </div>
</header>
