<?php
get_header();
?>
<section class="archive-hero">
    <div class="container">
        <div class="section-kicker"><?php esc_html_e( 'Movie Search', 'moviehub' ); ?></div>
        <h1 class="section-title">
            <?php printf( esc_html__( 'Results for “%s”', 'moviehub' ), esc_html( get_search_query() ) ); ?>
        </h1>
        <div class="search-results-form">
            <?php get_search_form(); ?>
        </div>
    </div>
</section>

<section class="section">
    <div class="container archive-layout">
        <main>
            <?php if ( have_posts() ) : ?>
                <div class="search-results-meta">
                    <?php
                    global $wp_query;
                    printf(
                        esc_html( _n( '%s movie found', '%s movies found', $wp_query->found_posts, 'moviehub' ) ),
                        esc_html( number_format_i18n( $wp_query->found_posts ) )
                    );
                    ?>
                </div>
                <div class="movie-grid">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php get_template_part( 'template-parts/movie-card' ); ?>
                    <?php endwhile; ?>
                </div>
                <?php get_template_part( 'template-parts/pagination' ); ?>
            <?php else : ?>
                <div class="content-card no-search-results">
                    <h2><?php esc_html_e( 'No movies found', 'moviehub' ); ?></h2>
                    <p><?php esc_html_e( 'Try another movie title, actor, director, or keyword.', 'moviehub' ); ?></p>
                    <?php get_search_form(); ?>
                </div>
            <?php endif; ?>
        </main>
        <?php get_sidebar(); ?>
    </div>
</section>
<?php get_footer(); ?>
