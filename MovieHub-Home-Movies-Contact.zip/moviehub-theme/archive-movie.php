<?php
/**
 * Movie archive page.
 * Shows every published MovieHub movie with pagination and a genre filter.
 */
get_header();

$paged = max( 1, get_query_var( 'paged' ) );
$genre = isset( $_GET['genre'] ) ? sanitize_title( wp_unslash( $_GET['genre'] ) ) : '';

$args = array(
    'post_type'      => 'movie',
    'post_status'    => 'publish',
    'posts_per_page' => 8,
    'paged'          => $paged,
);

if ( $genre ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => 'genre',
            'field'    => 'slug',
            'terms'    => $genre,
        ),
    );
}

$movies = new WP_Query( $args );
$genres = get_terms(
    array(
        'taxonomy'   => 'genre',
        'hide_empty' => true,
    )
);
?>

<section class="archive-hero">
    <div class="container">
        <div class="section-kicker"><?php esc_html_e( 'Movie Library', 'moviehub' ); ?></div>
        <h1 class="section-title"><?php esc_html_e( 'All Movies', 'moviehub' ); ?></h1>
        <p class="section-description">
            <?php esc_html_e( 'Browse the full MovieHub collection. Open a movie to see its details, cast, trailer, rating, and more.', 'moviehub' ); ?>
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="archive-toolbar">
            <div>
                <strong><?php echo esc_html( $movies->found_posts ); ?></strong>
                <?php esc_html_e( ' movies available', 'moviehub' ); ?>
            </div>

            <?php if ( ! is_wp_error( $genres ) && ! empty( $genres ) ) : ?>
                <form class="archive-filter" method="get" action="<?php echo esc_url( get_post_type_archive_link( 'movie' ) ); ?>">
                    <label for="movie-genre-filter"><?php esc_html_e( 'Genre', 'moviehub' ); ?></label>
                    <select id="movie-genre-filter" name="genre" onchange="this.form.submit()">
                        <option value=""><?php esc_html_e( 'All genres', 'moviehub' ); ?></option>
                        <?php foreach ( $genres as $item ) : ?>
                            <option value="<?php echo esc_attr( $item->slug ); ?>" <?php selected( $genre, $item->slug ); ?>>
                                <?php echo esc_html( $item->name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ( $genre ) : ?>
                        <a class="filter-clear" href="<?php echo esc_url( get_post_type_archive_link( 'movie' ) ); ?>">
                            <?php esc_html_e( 'Clear', 'moviehub' ); ?>
                        </a>
                    <?php endif; ?>
                </form>
            <?php endif; ?>
        </div>

        <div class="archive-layout">
            <main>
                <?php if ( $movies->have_posts() ) : ?>
                    <div class="movie-grid">
                        <?php while ( $movies->have_posts() ) : $movies->the_post(); ?>
                            <?php get_template_part( 'template-parts/movie-card' ); ?>
                        <?php endwhile; ?>
                    </div>

                    <?php
                    get_template_part(
                        'template-parts/pagination',
                        null,
                        array(
                            'query' => $movies,
                        )
                    );
                    ?>
                <?php else : ?>
                    <div class="content-card">
                        <h2><?php esc_html_e( 'No movies found', 'moviehub' ); ?></h2>
                        <p><?php esc_html_e( 'Try another genre or add a new movie from the WordPress dashboard.', 'moviehub' ); ?></p>
                        <a class="btn btn-primary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=movie' ) ); ?>">
                            <?php esc_html_e( 'Add New Movie', 'moviehub' ); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </main>

            <?php get_sidebar(); ?>
        </div>
    </div>
</section>

<?php
wp_reset_postdata();
get_footer();
