<?php
/**
 * Front page template.
 */
get_header();
$slider_query = moviehub_get_slider_movies();
?>

<section class="hero" data-slider>
    <?php if ( $slider_query->have_posts() ) : ?>
        <div class="hero-track">
            <?php $slide_index = 0; ?>
            <?php while ( $slider_query->have_posts() ) : $slider_query->the_post(); ?>
                <?php
                $rating        = get_post_meta( get_the_ID(), '_moviehub_rating', true );
                $year          = get_post_meta( get_the_ID(), '_moviehub_release_year', true );
                $hero_subtitle = get_post_meta( get_the_ID(), '_moviehub_hero_subtitle', true );
                $button_text   = get_post_meta( get_the_ID(), '_moviehub_button_text', true );
                $genres        = get_the_terms( get_the_ID(), 'genre' );
                $background    = get_the_post_thumbnail_url( get_the_ID(), 'full' );
                if ( ! $background ) {
                    $background = get_template_directory_uri() . '/assets/images/movie-placeholder.svg';
                }
                ?>
                <article class="hero-slide <?php echo 0 === $slide_index ? 'is-active' : ''; ?>" data-slide="<?php echo esc_attr( $slide_index ); ?>">
                    <div class="hero-backdrop" style="background-image:url('<?php echo esc_url( $background ); ?>');"></div>
                    <div class="hero-overlay"></div>
                    <div class="container hero-content">
                        <div class="hero-copy">
                            <div class="eyebrow"><span class="eyebrow-dot"></span><?php esc_html_e( 'Featured Movie', 'moviehub' ); ?></div>
                            <h1 class="hero-title"><?php the_title(); ?></h1>
                            <?php if ( $hero_subtitle ) : ?>
                                <p class="hero-excerpt"><?php echo esc_html( $hero_subtitle ); ?></p>
                            <?php elseif ( has_excerpt() ) : ?>
                                <p class="hero-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
                            <?php else : ?>
                                <p class="hero-excerpt"><?php echo esc_html( moviehub_trim_excerpt( get_the_content(), 28 ) ); ?></p>
                            <?php endif; ?>
                            <div class="hero-meta">
                                <?php if ( $year ) : ?><span class="meta-pill"><?php echo esc_html( $year ); ?></span><?php endif; ?>
                                <?php if ( $rating ) : ?><span class="meta-pill rating">★ <?php echo esc_html( $rating ); ?>/10</span><?php endif; ?>
                                <?php if ( $genres && ! is_wp_error( $genres ) ) : ?><span class="meta-pill"><?php echo esc_html( $genres[0]->name ); ?></span><?php endif; ?>
                            </div>
                            <div class="hero-actions">
                                <a class="btn btn-primary" href="<?php the_permalink(); ?>"><?php echo esc_html( $button_text ? $button_text : __( 'View Movie', 'moviehub' ) ); ?></a>
                                <a class="btn btn-ghost" href="#latest-movies"><?php esc_html_e( 'Browse Movies', 'moviehub' ); ?></a>
                            </div>
                        </div>
                    </div>
                </article>
                <?php $slide_index++; ?>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>

        <div class="hero-nav" aria-label="<?php esc_attr_e( 'Hero slider controls', 'moviehub' ); ?>">
            <div class="slider-controls">
                <button class="slider-control" type="button" data-slider-prev aria-label="<?php esc_attr_e( 'Previous movie', 'moviehub' ); ?>">←</button>
                <button class="slider-control" type="button" data-slider-next aria-label="<?php esc_attr_e( 'Next movie', 'moviehub' ); ?>">→</button>
            </div>
            <div class="slider-dots">
                <?php for ( $i = 0; $i < $slide_index; $i++ ) : ?>
                    <button class="slider-dot <?php echo 0 === $i ? 'is-active' : ''; ?>" type="button" data-slider-dot="<?php echo esc_attr( $i ); ?>" aria-label="<?php printf( esc_attr__( 'Go to slide %d', 'moviehub' ), $i + 1 ); ?>"></button>
                <?php endfor; ?>
            </div>
        </div>
    <?php else : ?>
        <div class="container hero-content">
            <div class="hero-copy">
                <div class="eyebrow"><span class="eyebrow-dot"></span><?php esc_html_e( 'MovieHub', 'moviehub' ); ?></div>
                <h1 class="hero-title"><?php esc_html_e( 'Your next favorite movie starts here.', 'moviehub' ); ?></h1>
                <p class="hero-excerpt"><?php esc_html_e( 'Add your first movie from WordPress → Movies to populate this homepage automatically.', 'moviehub' ); ?></p>
                <a class="btn btn-primary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=movie' ) ); ?>"><?php esc_html_e( 'Add Your First Movie', 'moviehub' ); ?></a>
            </div>
        </div>
    <?php endif; ?>
</section>

<section class="section" id="latest-movies">
    <div class="container">
        <div class="section-heading">
            <div><div class="section-kicker"><?php esc_html_e( 'Watchlist', 'moviehub' ); ?></div><h2 class="section-title"><?php esc_html_e( 'Latest Movies', 'moviehub' ); ?></h2></div>
            <a class="btn btn-ghost" href="<?php echo esc_url( get_post_type_archive_link( 'movie' ) ); ?>"><?php esc_html_e( 'See All', 'moviehub' ); ?> →</a>
        </div>
        <?php
        $latest = new WP_Query( array(
            'post_type'      => 'movie',
            'posts_per_page' => 8,
            'post_status'    => 'publish',
        ) );
        if ( $latest->have_posts() ) :
        ?>
            <div class="movie-grid">
                <?php while ( $latest->have_posts() ) : $latest->the_post(); get_template_part( 'template-parts/movie-card' ); endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <div class="content-card"><p><?php esc_html_e( 'No movies yet. Add movies from the WordPress dashboard.', 'moviehub' ); ?></p></div>
        <?php endif; ?>
    </div>
</section>

<section class="section" id="discover">
    <div class="container">
        <div class="feature-split">
            <div class="feature-panel image" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/images/cinema-placeholder.svg' ); ?>');"></div>
            <div class="feature-panel content">
                <div class="section-kicker"><?php esc_html_e( 'Built for Movie Fans', 'moviehub' ); ?></div>
                <h2><?php esc_html_e( 'Organize movies your way.', 'moviehub' ); ?></h2>
                <p><?php esc_html_e( 'MovieHub is designed so you can update titles, descriptions, featured images, ratings, genres, directors, cast, and trailer links directly from WordPress.', 'moviehub' ); ?></p>
                <div><a class="btn btn-primary" href="<?php echo esc_url( get_post_type_archive_link( 'movie' ) ); ?>"><?php esc_html_e( 'Explore Movie Library', 'moviehub' ); ?></a></div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
